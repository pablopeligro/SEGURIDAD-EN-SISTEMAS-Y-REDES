#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h" 
#include "ns3/applications-module.h"
#include "ns3/netanim-module.h"       
#include "ns3/ipv4-global-routing-helper.h"
#include "ns3/csma-module.h"           



using namespace ns3;

NS_LOG_COMPONENT_DEFINE("Reto6Simulacion"); 

int main(int argc, char *argv[]) {
   

    Time::SetResolution(Time::NS); 
    LogComponentEnable("UdpEchoClientApplication", LOG_LEVEL_INFO);
    LogComponentEnable("UdpEchoServerApplication", LOG_LEVEL_INFO);
    LogComponentEnable("Reto6Simulacion", LOG_LEVEL_INFO);

    NS_LOG_INFO("Iniciando simulación del Reto 6...");

    NS_LOG_INFO("Creando nodos...");
    NodeContainer todosLosNodos; 

    NodeContainer routerNodeContainer;
    routerNodeContainer.Create(1);
    Ptr<Node> router = routerNodeContainer.Get(0);
    todosLosNodos.Add(router);

    NodeContainer servidorContainer;
    servidorContainer.Create(1);
    Ptr<Node> servidor = servidorContainer.Get(0);
    todosLosNodos.Add(servidor);

    NodeContainer clientesLegitimosContainer;
    clientesLegitimosContainer.Create(2);
    todosLosNodos.Add(clientesLegitimosContainer);

    NodeContainer atacantesContainer;
    atacantesContainer.Create(3); 
    todosLosNodos.Add(atacantesContainer);

    NS_LOG_INFO("Configurando enlaces punto a punto...");
    PointToPointHelper p2pRouterServidor, p2pRouterCliente, p2pRouterAtacante;

    p2pRouterServidor.SetDeviceAttribute("DataRate", StringValue("10Mbps")); 
    p2pRouterServidor.SetChannelAttribute("Delay", StringValue("10ms"));
    NetDeviceContainer devRouterServidor = p2pRouterServidor.Install(router, servidor);

    NetDeviceContainer devClientesRouter[clientesLegitimosContainer.GetN()];
    for (uint32_t i = 0; i < clientesLegitimosContainer.GetN(); ++i) {
        p2pRouterCliente.SetDeviceAttribute("DataRate", StringValue("5Mbps"));
        p2pRouterCliente.SetChannelAttribute("Delay", StringValue("5ms"));
        devClientesRouter[i] = p2pRouterCliente.Install(clientesLegitimosContainer.Get(i), router);
    }

    NetDeviceContainer devAtacantesRouter[atacantesContainer.GetN()];
    for (uint32_t i = 0; i < atacantesContainer.GetN(); ++i) {
        p2pRouterAtacante.SetDeviceAttribute("DataRate", StringValue("100Mbps")); 
        p2pRouterAtacante.SetChannelAttribute("Delay", StringValue("2ms"));
        devAtacantesRouter[i] = p2pRouterAtacante.Install(atacantesContainer.Get(i), router);
    }

    NS_LOG_INFO("Instalando pila de Internet...");
    InternetStackHelper stack;
    stack.Install(todosLosNodos);

    NS_LOG_INFO("Asignando direcciones IP...");
    Ipv4AddressHelper address;
    Ipv4InterfaceContainer ifaceServidor, ifaceRouterServidor;
    Ipv4InterfaceContainer ifacesClientes[clientesLegitimosContainer.GetN()], ifacesRouterClientes[clientesLegitimosContainer.GetN()];
    Ipv4InterfaceContainer ifacesAtacantes[atacantesContainer.GetN()], ifacesRouterAtacantes[atacantesContainer.GetN()];

    address.SetBase("10.1.1.0", "255.255.255.0");
    ifaceServidor = address.Assign(devRouterServidor.Get(1));     
    ifaceRouterServidor = address.Assign(devRouterServidor.Get(0)); 

    for (uint32_t i = 0; i < clientesLegitimosContainer.GetN(); ++i) {
        std::ostringstream net;
        net << "10.1." << 2 + i << ".0";
        address.SetBase(Ipv4Address(net.str().c_str()), "255.255.255.0");
        ifacesClientes[i] = address.Assign(devClientesRouter[i].Get(0));      
        ifacesRouterClientes[i] = address.Assign(devClientesRouter[i].Get(1)); 
    }

    for (uint32_t i = 0; i < atacantesContainer.GetN(); ++i) {
        std::ostringstream net;
        net << "192.168." << 1 + i << ".0";
        address.SetBase(Ipv4Address(net.str().c_str()), "255.255.255.0");
        ifacesAtacantes[i] = address.Assign(devAtacantesRouter[i].Get(0));      
        ifacesRouterAtacantes[i] = address.Assign(devAtacantesRouter[i].Get(1)); 
    }

    NS_LOG_INFO("Poblando tablas de enrutamiento...");
    Ipv4GlobalRoutingHelper::PopulateRoutingTables();

    NS_LOG_INFO("Configurando aplicaciones...");
    uint16_t port = 80; 

    PacketSinkHelper packetSinkHelper("ns3::UdpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(), port));
    ApplicationContainer servidorApp = packetSinkHelper.Install(servidor);
    servidorApp.Start(Seconds(1.0));
    servidorApp.Stop(Seconds(30.0));

    for (uint32_t i = 0; i < clientesLegitimosContainer.GetN(); ++i) {
        OnOffHelper clienteHelper("ns3::UdpSocketFactory", InetSocketAddress(ifaceServidor.GetAddress(0), port));
        clienteHelper.SetAttribute("OnTime", StringValue("ns3::ConstantRandomVariable[Constant=1]"));
        clienteHelper.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=1]"));
        clienteHelper.SetAttribute("DataRate", DataRateValue(DataRate("64kbps"))); 
        clienteHelper.SetAttribute("PacketSize", UintegerValue(512));

        ApplicationContainer clienteApp = clienteHelper.Install(clientesLegitimosContainer.Get(i));
        clienteApp.Start(Seconds(2.0)); 
        clienteApp.Stop(Seconds(28.0));
    }

    double tiempoInicioAtaque = 10.0;
    double tiempoFinAtaque = 25.0;
    for (uint32_t i = 0; i < atacantesContainer.GetN(); ++i) {
        OnOffHelper atacanteHelper("ns3::UdpSocketFactory", InetSocketAddress(ifaceServidor.GetAddress(0), port));
        atacanteHelper.SetAttribute("OnTime", StringValue("ns3::ConstantRandomVariable[Constant=1]")); 
        atacanteHelper.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0]"));
        atacanteHelper.SetAttribute("DataRate", DataRateValue(DataRate("5Mbps"))); 
        atacanteHelper.SetAttribute("PacketSize", UintegerValue(1024));

        ApplicationContainer atacanteApp = atacanteHelper.Install(atacantesContainer.Get(i));
        atacanteApp.Start(Seconds(tiempoInicioAtaque));
        atacanteApp.Stop(Seconds(tiempoFinAtaque));
    }

    
    NS_LOG_INFO("Configurando NetAnim...");
    AnimationInterface anim("reto6-animacion.xml");
    anim.SetConstantPosition(router, 50.0, 50.0);
    anim.SetConstantPosition(servidor, 70.0, 50.0);
    anim.UpdateNodeDescription(servidor, "Servidor_Victima");
    anim.UpdateNodeColor(servidor, 0, 0, 255); 

    for (uint32_t i = 0; i < clientesLegitimosContainer.GetN(); ++i) {
        anim.SetConstantPosition(clientesLegitimosContainer.Get(i), 30.0, 30.0 + i * 20.0);
        anim.UpdateNodeDescription(clientesLegitimosContainer.Get(i), "Cliente_Legitimo_" + std::to_string(i));
        anim.UpdateNodeColor(clientesLegitimosContainer.Get(i), 0, 255, 0); 
    }
    for (uint32_t i = 0; i < atacantesContainer.GetN(); ++i) {
        anim.SetConstantPosition(atacantesContainer.Get(i), 10.0, 30.0 + i * 20.0);
        anim.UpdateNodeDescription(atacantesContainer.Get(i), "Atacante_" + std::to_string(i));
        anim.UpdateNodeColor(atacantesContainer.Get(i), 255, 0, 0); 
    }
    anim.UpdateNodeDescription(router, "Router_Borde");


    Simulator::Stop(Seconds(30.0));
    Simulator::Run();
    Simulator::Destroy();

    return 0;
}